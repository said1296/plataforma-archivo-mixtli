<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="">
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CRaleway:600,400%7CHind' rel='stylesheet'>
<link rel="stylesheet" href="../../themes/css/bootstrap.min.css" />
<link rel="stylesheet" href="../../themes/css/magnific-popup.css" />
<link rel="stylesheet" href="../../themes/css/settings.css" />
<link rel="stylesheet" href="../../themes/css/rev-slider.css" />
<link rel="stylesheet" href="../../themes/css/font-icons.css" />
<link rel="stylesheet" href="../../themes/css/sliders.css" /> 
<link rel="stylesheet" href="../../themes/css/style.css" />
<link rel="stylesheet" href="../../themes/css/responsive.css" />
<link rel="stylesheet" href="../../themes/css/spacings.css" />
<link rel="stylesheet" href="../../themes/css/animate.min.css" />
<link rel="shortcut icon" href="../../themes/img/gral/ico.png">
<link rel="apple-touch-icon" href="../../themes/img/gral/ico.png">
<link rel="stylesheet" href="../../themes/css/misc.css" />